<?php
if (!isset($selector)) {
	$selector = '[data-column="footer-one"]';
}
