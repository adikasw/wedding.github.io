<?php

$config = [
	'name' => __('Contacts', 'rishi'),
	'visibilityKey' => 'footer_hide_contacts',
	'typography_keys' => ['contacts_font'],
];
