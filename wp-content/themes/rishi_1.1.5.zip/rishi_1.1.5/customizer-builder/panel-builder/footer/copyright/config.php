<?php
$config = [
	'name' => __('Copyright', 'rishi'),
	'visibilityKey' => 'footer_hide_copyright',
	'typography_keys' => ['copyrightFont'],
	'translation_keys' => [
		['key' => 'copyright_text']
	]
];
