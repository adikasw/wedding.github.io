<?php

$config = [
	'name' => __('Socials', 'rishi'),
	'visibilityKey' => 'footer_hide_social',
	'clone' => true,
];
