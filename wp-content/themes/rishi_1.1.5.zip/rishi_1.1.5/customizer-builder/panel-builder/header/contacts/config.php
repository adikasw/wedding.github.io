<?php

$config = [
	'name' => __('Contacts', 'rishi'),
	'typography_keys' => ['contacts_font'],
	'visibilityKey' => 'header_hide_contacts',
];
