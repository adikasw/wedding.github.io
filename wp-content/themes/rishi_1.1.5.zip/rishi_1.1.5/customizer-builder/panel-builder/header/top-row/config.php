<?php

$config = [
	'name' => __('Top Row', 'rishi')
];
