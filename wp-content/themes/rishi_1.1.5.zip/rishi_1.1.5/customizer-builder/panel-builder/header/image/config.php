<?php
$config = [
	'name'              => __('Image', 'rishi'),
	'visibilityKey'     => 'header_hide_image',
	'selective_refresh' => ['rt_header_image','header_image_link']
];
