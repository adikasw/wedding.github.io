<?php

$config = [
	'name' => __('Bottom Row', 'rishi'),
];
